import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Dashboard.css";

/*
  MyFitness Dashboard
  ---------------------------------------------------------
  Asset folder:
  public/assets/dashboard/

  Put these images in that folder:
  1. myfitness-logo.png
  2. dashboard-hero.jpg
  3. profile-avatar.jpg
  4. workout-upper-body.jpg
  5. nutrition-chicken-bowl.jpg
  6. ai-fitness-robot.png
  7. dashboard-bottom-banner.jpg
  8. dashboard-leaves.png

  The dashboard also reads setup information from localStorage.
  It supports common key names so it can be connected to your
  existing setup pages without changing the visual design.
*/

const readStorage = (keys, fallback) => {
  for (const key of keys) {
    const value = localStorage.getItem(key);
    if (value !== null && value !== "") return value;
  }
  return fallback;
};

const parseNumber = (value, fallback) => {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
};

function Dashboard() {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [activeNav, setActiveNav] = useState("Home");

  const profile = useMemo(() => {
    const age = parseNumber(
      readStorage(["age", "userAge", "profileAge"], "21"),
      21
    );
    const height = parseNumber(
      readStorage(["height", "userHeight", "heightCm"], "175"),
      175
    );
    const weight = parseNumber(
      readStorage(["weight", "userWeight", "weightKg"], "70"),
      70
    );

    const gender = readStorage(
      ["gender", "userGender", "selectedGender"],
      "Male"
    );

    const goal = readStorage(
      ["fitnessGoal", "goal", "selectedGoal", "fitness_goal"],
      "Build Muscle"
    );

    const name = readStorage(
      ["name", "userName", "fullName", "profileName"],
      "Harsh"
    );

    const bmi = weight / Math.pow(height / 100, 2);

    return {
      name,
      age,
      height,
      weight,
      gender,
      goal,
      bmi: bmi.toFixed(1),
    };
  }, []);

  const firstName = profile.name.trim().split(" ")[0] || "Harsh";

  const goalData = {
    "Build Muscle": {
      title: "Build Muscle",
      subtitle: "Stronger. Fitter. Healthier You.",
    },
    "Lose Weight": {
      title: "Lose Weight",
      subtitle: "Lighter. Stronger. Healthier You.",
    },
    "Weight Loss": {
      title: "Lose Weight",
      subtitle: "Lighter. Stronger. Healthier You.",
    },
    "Stay Fit": {
      title: "Stay Fit",
      subtitle: "Move Better. Feel Better. Live Better.",
    },
    "Improve Fitness": {
      title: "Improve Fitness",
      subtitle: "Build stamina. Build confidence.",
    },
  };

  const selectedGoal = goalData[profile.goal] || {
    title: profile.goal,
    subtitle: "Your personalized fitness journey.",
  };

  const navItems = [
    ["Home", "⌂"],
    ["Workouts", "♟"],
    ["Nutrition", "♜"],
    ["Progress", "▥"],
    ["Community", "♧"],
    ["AI Coach", "✦"],
    ["Profile", "♙"],
  ];

  const askAI = () => {
    const text = query.trim();
    if (!text) {
      navigate("/ai-coach");
      return;
    }
    navigate(`/ai-coach?query=${encodeURIComponent(text)}`);
  };

  const handleNav = (item) => {
    setActiveNav(item);

    const routes = {
      Home: "/dashboard",
      Workouts: "/workout",
      Nutrition: "/nutrition",
      Progress: "/progress",
      Community: "/community",
      "AI Coach": "/ai-coach",
      Profile: "/profile",
    };

    if (routes[item]) navigate(routes[item]);
  };

  return (
    <div className="mf-dashboard">
      {/* =========================================================
          SIDEBAR
      ========================================================= */}
      <aside className="mf-sidebar">
        <div className="mf-sidebar-brand">
          <img
            src="/assets/dashboard/myfitness-logo.png"
            alt="MyFitness"
            className="mf-logo"
          />
          <div>
            <div className="mf-brand-name">
              MY<span>FITNESS</span>
            </div>
            <div className="mf-brand-subtitle">PERSONAL FITNESS</div>
          </div>
        </div>

        <nav className="mf-sidebar-nav">
          {navItems.map(([item, icon]) => (
            <button
              key={item}
              className={`mf-nav-item ${
                activeNav === item ? "active" : ""
              }`}
              onClick={() => handleNav(item)}
              type="button"
            >
              <span className="mf-nav-icon">{icon}</span>
              <span>{item}</span>
            </button>
          ))}
        </nav>

        <div className="mf-sidebar-bottom">
          <div className="mf-sidebar-mountain" />
          <div className="mf-side-motivation">
            <span>Be the</span>
            <strong>Healthiest<br />Version<br />of You</strong>
            <i />
          </div>
        </div>
      </aside>

      {/* =========================================================
          MAIN
      ========================================================= */}
      <main className="mf-main">

        {/* TOP BAR */}
        <header className="mf-topbar">
          <form
            className="mf-ai-search"
            onSubmit={(e) => {
              e.preventDefault();
              askAI();
            }}
          >
            <div className="mf-ai-orb">
              <span />
            </div>

            <div className="mf-search-copy">
              <strong>Ask MyFitness AI...</strong>
              <span>
                Workouts, nutrition, progress, health tips, or anything...
              </span>
            </div>

            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Ask MyFitness AI"
              placeholder=""
            />

            <button type="submit" className="mf-mic" aria-label="Ask AI">
              ♫
            </button>
          </form>

          <div className="mf-top-actions">
            <button className="mf-notification" type="button">
              ♧
              <span />
            </button>

            <button
              className="mf-user-button"
              type="button"
              onClick={() => navigate("/profile")}
            >
              <img
                src="/assets/dashboard/profile-avatar.jpg"
                alt="Profile"
              />
              <span>⌄</span>
            </button>
          </div>
        </header>

        {/* HERO */}
        <section className="mf-hero">
          <img
            src="/assets/dashboard/dashboard-hero.jpg"
            alt=""
            className="mf-hero-image"
          />
          <div className="mf-hero-overlay" />

          <div className="mf-hero-copy">
            <span className="mf-greeting">Good Morning,</span>
            <h1>
              {firstName} <b>👋</b>
            </h1>
            <p>Consistency today builds a stronger you tomorrow.</p>

            <div className="mf-quote">
              <strong>“</strong>
              <div>
                <em>Discipline turns goals into results.</em>
                <small>— MyFitness</small>
              </div>
            </div>
          </div>

          <div className="mf-hero-script">
            Stronger
            <br />
            <span>Everyday</span>
            <b>♥</b>
          </div>

          <div className="mf-date-card">
            <span>▣</span>
            <div>
              <strong>Today</strong>
              <small>Keep going!</small>
            </div>
          </div>
        </section>

        {/* QUICK STATS */}
        <section className="mf-stat-grid">
          <StatCard
            icon="🔥"
            value="1,850"
            unit="kcal"
            detail="520 left"
            progress="74%"
            tone="orange"
          />
          <StatCard
            icon="👟"
            value="8,432"
            unit="Steps"
            detail="Daily Goal 10,000"
            progress="84%"
            tone="mint"
          />
          <StatCard
            icon="◷"
            value="42"
            unit="min"
            detail="Great job!"
            progress="70%"
            tone="blue"
          />
          <StatCard
            icon="💧"
            value="2.1"
            unit="L"
            detail="Goal 3.0 L"
            progress="70%"
            tone="cyan"
          />
        </section>

        {/* GOAL + PROFILE */}
        <section className="mf-two-grid">
          <article className="mf-goal-card">
            <div className="mf-goal-content">
              <div className="mf-card-heading">
                <span className="mf-heading-icon">◎</span>
                <strong>Your Fitness Goal</strong>
              </div>

              <h2>{selectedGoal.title}</h2>
              <p>{selectedGoal.subtitle}</p>

              <div className="mf-track-pill">
                <span>◔</span>
                <strong>On Track</strong>
                <i>
                  <b />
                </i>
              </div>
            </div>

            <div className="mf-goal-dumbbell">🏋️</div>
            <div className="mf-goal-script">
              Discipline
              <br />
              Builds
              <br />
              <span>Freedom</span>
            </div>
          </article>

          <article className="mf-profile-card">
            <div className="mf-profile-top">
              <div className="mf-profile-person">
                <img
                  src="/assets/dashboard/profile-avatar.jpg"
                  alt={profile.name}
                />
                <h3>Your Profile</h3>
              </div>
              <button
                type="button"
                onClick={() => navigate("/profile")}
              >
                View Profile →
              </button>
            </div>

            <div className="mf-profile-metrics">
              <MiniMetric icon="♙" value={profile.age} label="Age" suffix="years" />
              <MiniMetric icon="♂" value={profile.gender} label="Gender" />
              <MiniMetric icon="↕" value={profile.height} label="Height" suffix="cm" />
              <MiniMetric icon="▱" value={profile.weight} label="Weight" suffix="kg" />
            </div>
          </article>
        </section>

        {/* WORKOUT + BODY + NUTRITION */}
        <section className="mf-content-grid">

          {/* WORKOUT */}
          <article className="mf-panel mf-workout-panel">
            <PanelTitle
              icon="🏋"
              title="Today's Workout"
              action="View Plan"
              onClick={() => navigate("/workout")}
            />

            <div className="mf-workout-feature">
              <img
                src="/assets/dashboard/workout-upper-body.jpg"
                alt="Upper body workout"
              />
              <div className="mf-play">▶</div>

              <div className="mf-workout-info">
                <span className="mf-tag">Upper Body Strength</span>
                <span>8 exercises • 32 min</span>
                <span className="mf-level">Intermediate</span>

                <button
                  type="button"
                  onClick={() => navigate("/workout")}
                >
                  Start Workout <b>→</b>
                </button>
              </div>
            </div>

            <ExerciseRow name="Push Ups" reps="3 × 12" />
            <ExerciseRow name="Dumbbell Press" reps="3 × 10" />
            <ExerciseRow name="Bent Over Row" reps="3 × 12" />
            <ExerciseRow name="Shoulder Press" reps="3 × 10" />
          </article>

          {/* BODY METRICS */}
          <article className="mf-panel mf-body-panel">
            <PanelTitle
              icon="⚖"
              title="Body Metrics"
              action="View Details"
              onClick={() => navigate("/body-metrics")}
            />

            <div className="mf-bmi-ring">
              <div>
                <strong>{profile.bmi}</strong>
                <span>BMI</span>
              </div>
            </div>

            <div className="mf-health-label">Healthy</div>

            <div className="mf-body-stats">
              <MiniBody value={`${profile.weight} kg`} label="Weight" />
              <MiniBody value={`${profile.height} cm`} label="Height" />
              <MiniBody value="16 %" label="Body Fat" />
              <MiniBody value="58 kg" label="Muscle Mass" />
            </div>
          </article>

          {/* NUTRITION */}
          <article className="mf-panel mf-nutrition-panel">
            <PanelTitle
              icon="🍴"
              title="Nutrition Today"
              action="Log Meal"
              onClick={() => navigate("/nutrition")}
            />

            <div className="mf-nutrition-top">
              <div className="mf-calorie-ring">
                <div>
                  <strong>1,640</strong>
                  <span>/ 2,200 kcal</span>
                </div>
              </div>

              <div className="mf-macros">
                <Macro color="orange" name="Protein" value="120g" />
                <Macro color="mint" name="Carbs" value="180g" />
                <Macro color="yellow" name="Fats" value="60g" />
              </div>
            </div>

            <div className="mf-meal-card">
              <img
                src="/assets/dashboard/nutrition-chicken-bowl.jpg"
                alt="Grilled chicken bowl"
              />
              <div>
                <strong>Grilled Chicken Bowl</strong>
                <span>520 kcal • 42g Protein</span>
              </div>
              <button type="button">View</button>
            </div>
          </article>

          {/* AI COACH */}
          <article className="mf-ai-card">
            <div className="mf-ai-card-glow" />
            <img
              src="/assets/dashboard/ai-fitness-robot.png"
              alt="AI Fitness Assistant"
              className="mf-ai-robot"
            />
            <div className="mf-ai-copy">
              <span className="mf-ai-small">AI FITNESS ASSISTANT</span>
              <h3>Train smarter<br />with MyFitness AI.</h3>
              <p>
                Get personalized advice, workout plans,
                nutrition tips and more.
              </p>

              <button
                type="button"
                onClick={() => navigate("/ai-coach")}
              >
                Start a Conversation <b>→</b>
              </button>

              <div className="mf-ai-prompts">
                <button type="button">Suggest a workout</button>
                <button type="button">Meal plan for muscle gain</button>
                <button type="button">How to improve sleep?</button>
              </div>
            </div>
          </article>
        </section>

        {/* WEEKLY + ACHIEVEMENTS */}
        <section className="mf-bottom-grid">
          <article className="mf-panel mf-weekly-panel">
            <PanelTitle
              icon="▤"
              title="Weekly Progress"
              action="Steps"
              onClick={() => navigate("/progress")}
            />

            <div className="mf-chart">
              {[
                ["Mon", "6.2k", 62],
                ["Tue", "8.4k", 84],
                ["Wed", "7.1k", 71],
                ["Thu", "9.3k", 93],
                ["Fri", "8.0k", 80],
                ["Sat", "7.6k", 76],
                ["Sun", "8.4k", 84],
              ].map(([day, value, height], index) => (
                <div className="mf-bar-wrap" key={day}>
                  <span>{value}</span>
                  <div className="mf-bar" style={{ height: `${height}%` }}>
                    <i />
                  </div>
                  <small className={index === 6 ? "selected" : ""}>
                    {day}
                  </small>
                </div>
              ))}
            </div>
          </article>

          <article className="mf-panel mf-achievements-panel">
            <PanelTitle
              icon="✦"
              title="Achievements"
              action="View All"
              onClick={() => navigate("/progress")}
            />

            <div className="mf-achievements">
              <Achievement icon="👟" value="7" label="Day Streak" />
              <Achievement icon="🔥" value="5" label="Workouts" />
              <Achievement icon="★" value="1" label="Goal Closer" />
            </div>
          </article>
        </section>

        {/* BOTTOM BANNER + QUOTE */}
        <section className="mf-last-grid">
          <article className="mf-bottom-banner">
            <img
              src="/assets/dashboard/dashboard-bottom-banner.jpg"
              alt=""
            />
            <div>
              <strong>Small Steps</strong>
              <strong>Big Results</strong>
              <span>Keep showing up.</span>
            </div>
            <button type="button" onClick={() => navigate("/progress")}>
              →
            </button>
          </article>

          <article className="mf-bottom-quote">
            <span>“</span>
            <div>
              <em>A healthier you<br />is a happier you.</em>
              <small>— MyFitness</small>
            </div>
            <img
              src="/assets/dashboard/dashboard-leaves.png"
              alt=""
            />
          </article>
        </section>

        <footer className="mf-dashboard-footer">
          <span>MYFITNESS • PERSONAL FITNESS</span>
          <span>TRAIN SMARTER • MOVE STRONGER</span>
          <strong>{firstName.toUpperCase()} • DASHBOARD</strong>
        </footer>
      </main>
    </div>
  );
}

function StatCard({ icon, value, unit, detail, progress, tone }) {
  return (
    <article className={`mf-stat-card ${tone}`}>
      <div className="mf-stat-icon">{icon}</div>
      <div className="mf-stat-main">
        <div>
          <strong>{value}</strong>
          <span>{unit}</span>
        </div>
        <small>{detail}</small>
        <div className="mf-stat-progress">
          <i style={{ width: progress }} />
        </div>
      </div>
    </article>
  );
}

function MiniMetric({ icon, value, label, suffix }) {
  return (
    <div className="mf-mini-metric">
      <span>{icon}</span>
      <strong>
        {value} {suffix && <small>{suffix}</small>}
      </strong>
      <em>{label}</em>
    </div>
  );
}

function PanelTitle({ icon, title, action, onClick }) {
  return (
    <div className="mf-panel-title">
      <div>
        <span>{icon}</span>
        <h3>{title}</h3>
      </div>
      <button type="button" onClick={onClick}>
        {action} <b>→</b>
      </button>
    </div>
  );
}

function ExerciseRow({ name, reps }) {
  return (
    <div className="mf-exercise-row">
      <span className="mf-checkbox" />
      <strong>{name}</strong>
      <small>{reps}</small>
    </div>
  );
}

function MiniBody({ value, label }) {
  return (
    <div className="mf-mini-body">
      <span>◌</span>
      <div>
        <strong>{value}</strong>
        <small>{label}</small>
      </div>
    </div>
  );
}

function Macro({ color, name, value }) {
  return (
    <div className="mf-macro">
      <span className={color} />
      <strong>{name}</strong>
      <small>{value}</small>
    </div>
  );
}

function Achievement({ icon, value, label }) {
  return (
    <div className="mf-achievement">
      <span>{icon}</span>
      <strong>{value}</strong>
      <small>{label}</small>
    </div>
  );
}

export default Dashboard;
