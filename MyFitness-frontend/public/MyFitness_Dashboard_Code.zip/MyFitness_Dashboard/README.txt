# MyFitness Dashboard

## Files

- `src/pages/Dashboard.jsx`
- `src/pages/Dashboard.css`

## Images used by the dashboard

Create this folder:

`public/assets/dashboard/`

Then place these files inside it:

1. `myfitness-logo.png` — MyFitness M/logo
2. `dashboard-hero.jpg` — mountain + person/backpack hero image
3. `profile-avatar.jpg` — user's profile photo
4. `workout-upper-body.jpg` — upper-body workout image
5. `nutrition-chicken-bowl.jpg` — grilled chicken/nutrition bowl
6. `ai-fitness-robot.png` — AI fitness assistant/robot
7. `dashboard-bottom-banner.jpg` — mountain + person motivational banner
8. `dashboard-leaves.png` — green leaves decoration

## App.jsx route

Use:

```jsx
import Dashboard from "./pages/Dashboard";
```

and inside `<Routes>`:

```jsx
<Route path="/dashboard" element={<Dashboard />} />
```

## Important flow

The intended flow is:

Setup → Profile Summary → Fitness Goal → Benefits → Dashboard

The Benefits page should contain:

```jsx
onClick={() => navigate("/dashboard")}
```

The dashboard reads age, height, weight, gender, goal and name from localStorage where available, with safe fallback values if your setup pages have not saved them yet.

If your setup pages use different localStorage key names, add those names to the arrays near the top of `Dashboard.jsx`.
